﻿Public Class frmDatabase

    Dim Customers As Object


    Private Sub frmDatabase_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Me.CustomersTableAdapter1.Fill(Me.Customers1DataSet.Customers)


    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        If txtAccountname.Text = "yoc123" And txtPassword.Text = "123" Then
            lstBox1.Visible = True
            lstBox2.Visible = False
            lstBox3.Visible = False
            lstBox4.Visible = False
            lstBox5.Visible = False

        End If

        If txtAccountname.Text = "al123" And txtPassword.Text = "123" Then
            lstBox1.Visible = False
            lstBox2.Visible = True
            lstBox3.Visible = False
            lstBox4.Visible = False
            lstBox5.Visible = False

        End If

        If txtAccountname.Text = "ag123" And txtPassword.Text = "123" Then
            lstBox1.Visible = False
            lstBox2.Visible = False
            lstBox3.Visible = True
            lstBox4.Visible = False
            lstBox5.Visible = False

        End If

        If txtAccountname.Text = "og123" And txtPassword.Text = "123" Then
            lstBox1.Visible = False
            lstBox2.Visible = False
            lstBox3.Visible = False
            lstBox4.Visible = True
            lstBox5.Visible = False

        End If

        If txtAccountname.Text = "bb123" And txtPassword.Text = "123" Then
            lstBox1.Visible = False
            lstBox2.Visible = False
            lstBox3.Visible = False
            lstBox4.Visible = False
            lstBox5.Visible = True

        End If


    End Sub

End Class
