﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatabase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Customers1DataSet = New Database_Project.customers1DataSet()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.lstBox1 = New System.Windows.Forms.ListBox()
        Me.CustomersTableAdapter1 = New Database_Project.customers1DataSetTableAdapters.CustomersTableAdapter()
        Me.lstBox2 = New System.Windows.Forms.ListBox()
        Me.lstBox3 = New System.Windows.Forms.ListBox()
        Me.lstBox4 = New System.Windows.Forms.ListBox()
        Me.lstBox5 = New System.Windows.Forms.ListBox()
        Me.lblAccountname = New System.Windows.Forms.Label()
        Me.txtAccountname = New System.Windows.Forms.TextBox()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Customers1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BindingSource1
        '
        Me.BindingSource1.DataSource = Me.Customers1DataSet
        Me.BindingSource1.Position = 0
        '
        'Customers1DataSet
        '
        Me.Customers1DataSet.DataSetName = "customers1DataSet"
        Me.Customers1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(438, 166)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(350, 39)
        Me.btnDisplay.TabIndex = 0
        Me.btnDisplay.Text = "Display Customer Details"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'lstBox1
        '
        Me.lstBox1.FormattingEnabled = True
        Me.lstBox1.ItemHeight = 16
        Me.lstBox1.Items.AddRange(New Object() {"Customer Name : Yvonne O Connor", "Order ID : 25849", "Account name : yoc123", "Shoe type : Classic = €54.49", "Add - ons : Vamp = € 14.99 , Laces = € 4.00 , Text = € 0.45", "Subtotal : €74.43", "Total (incl VAT) : €91.54"})
        Me.lstBox1.Location = New System.Drawing.Point(12, 57)
        Me.lstBox1.Name = "lstBox1"
        Me.lstBox1.Size = New System.Drawing.Size(363, 148)
        Me.lstBox1.TabIndex = 1
        Me.lstBox1.Visible = False
        '
        'CustomersTableAdapter1
        '
        Me.CustomersTableAdapter1.ClearBeforeFill = True
        '
        'lstBox2
        '
        Me.lstBox2.FormattingEnabled = True
        Me.lstBox2.ItemHeight = 16
        Me.lstBox2.Items.AddRange(New Object() {"Customer Name : Alicia Looney", "Order ID : 36724", "Account name : al123", "Shoe type : Retro = €49.50", "Add - ons : Quarter = € 8.99 , Heel tab = € 4.99", "Subtotal : €63.48", "Total (incl VAT) : €78.08"})
        Me.lstBox2.Location = New System.Drawing.Point(12, 57)
        Me.lstBox2.Name = "lstBox2"
        Me.lstBox2.Size = New System.Drawing.Size(363, 148)
        Me.lstBox2.TabIndex = 2
        Me.lstBox2.Visible = False
        '
        'lstBox3
        '
        Me.lstBox3.FormattingEnabled = True
        Me.lstBox3.ItemHeight = 16
        Me.lstBox3.Items.AddRange(New Object() {"Customer Name : Amy Gill", "Order ID : 45269", "Account name : ag123", "Shoe type : Vintage = €44.99", "Add - ons : Back counter = € 6.49 , Eyestay € 5.00", "Subtotal : €56.48", "Total (incl VAT) : €69.47"})
        Me.lstBox3.Location = New System.Drawing.Point(12, 57)
        Me.lstBox3.Name = "lstBox3"
        Me.lstBox3.Size = New System.Drawing.Size(363, 148)
        Me.lstBox3.TabIndex = 3
        Me.lstBox3.Visible = False
        '
        'lstBox4
        '
        Me.lstBox4.FormattingEnabled = True
        Me.lstBox4.ItemHeight = 16
        Me.lstBox4.Items.AddRange(New Object() {"Customer Name : Oisin Griffin", "Order ID : 75247", "Account name : og123", "Shoe type : Retro = €49.50", "Add - ons : Quarter = € 8.99 , Heel tab = € 4.99", "Subtotal : €63.48", "Total (incl VAT) : €78.08"})
        Me.lstBox4.Location = New System.Drawing.Point(12, 57)
        Me.lstBox4.Name = "lstBox4"
        Me.lstBox4.Size = New System.Drawing.Size(363, 148)
        Me.lstBox4.TabIndex = 4
        Me.lstBox4.Visible = False
        '
        'lstBox5
        '
        Me.lstBox5.FormattingEnabled = True
        Me.lstBox5.ItemHeight = 16
        Me.lstBox5.Items.AddRange(New Object() {"Customer Name : Bryan Brown", "Order ID : 85694", "Account name : bb123", "Shoe type : Classic = €54.49", "Add - ons : Vamp = € 14.99 , Laces = € 4.00", "Subtotal : €73.48", "Total (incl VAT) : €90.38"})
        Me.lstBox5.Location = New System.Drawing.Point(12, 57)
        Me.lstBox5.Name = "lstBox5"
        Me.lstBox5.Size = New System.Drawing.Size(363, 148)
        Me.lstBox5.TabIndex = 5
        Me.lstBox5.Visible = False
        '
        'lblAccountname
        '
        Me.lblAccountname.AutoSize = True
        Me.lblAccountname.Location = New System.Drawing.Point(435, 72)
        Me.lblAccountname.Name = "lblAccountname"
        Me.lblAccountname.Size = New System.Drawing.Size(106, 17)
        Me.lblAccountname.TabIndex = 6
        Me.lblAccountname.Text = "Account name :"
        '
        'txtAccountname
        '
        Me.txtAccountname.Location = New System.Drawing.Point(547, 72)
        Me.txtAccountname.Name = "txtAccountname"
        Me.txtAccountname.Size = New System.Drawing.Size(237, 22)
        Me.txtAccountname.TabIndex = 7
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(435, 129)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(77, 17)
        Me.lblPassword.TabIndex = 8
        Me.lblPassword.Text = "Password :"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(547, 129)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(237, 22)
        Me.txtPassword.TabIndex = 9
        '
        'frmDatabase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(865, 280)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lblPassword)
        Me.Controls.Add(Me.txtAccountname)
        Me.Controls.Add(Me.lblAccountname)
        Me.Controls.Add(Me.lstBox5)
        Me.Controls.Add(Me.lstBox4)
        Me.Controls.Add(Me.lstBox3)
        Me.Controls.Add(Me.lstBox2)
        Me.Controls.Add(Me.lstBox1)
        Me.Controls.Add(Me.btnDisplay)
        Me.Name = "frmDatabase"
        Me.Text = "Database"
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Customers1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents Customers1DataSet As customers1DataSet
    Friend WithEvents btnDisplay As Button
    Friend WithEvents lstBox1 As ListBox
    Friend WithEvents CustomersTableAdapter1 As customers1DataSetTableAdapters.CustomersTableAdapter
    Friend WithEvents lstBox2 As ListBox
    Friend WithEvents lstBox3 As ListBox
    Friend WithEvents lstBox4 As ListBox
    Friend WithEvents lstBox5 As ListBox
    Friend WithEvents lblAccountname As Label
    Friend WithEvents txtAccountname As TextBox
    Friend WithEvents lblPassword As Label
    Friend WithEvents txtPassword As TextBox
End Class
